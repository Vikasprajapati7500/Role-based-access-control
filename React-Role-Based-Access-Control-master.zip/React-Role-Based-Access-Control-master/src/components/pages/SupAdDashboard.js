import React, { Component } from 'react';

export default class SupAdDashboard extends Component {
  render() {
    return <h1>Super Admin Dashboard</h1>;
  }
}
