import React, { Component } from 'react';

export default class OrgDashboard extends Component {
  render() {
    return <h1>Organizer Dashboard</h1>;
  }
}
