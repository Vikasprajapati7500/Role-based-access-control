import React, { Component } from 'react';

export default class AdminDashboard extends Component {
  render() {
    return (
      <div>
        <h1>Admin Dashboard</h1>
      </div>
    );
  }
}
