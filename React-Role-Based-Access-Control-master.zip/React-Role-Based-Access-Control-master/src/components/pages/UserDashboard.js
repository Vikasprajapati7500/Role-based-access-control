import React, { Component } from 'react';

export default class UserDashboard extends Component {
  render() {
    return (
      <div>
        <h1>User Dashboard</h1>
      </div>
    );
  }
}
